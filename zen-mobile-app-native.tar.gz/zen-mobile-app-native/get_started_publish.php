<?php
wp2android_Admin::render_remote_view('get_started_publish');
?>