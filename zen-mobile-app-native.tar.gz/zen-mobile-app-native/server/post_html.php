<?php
if(!function_exists("file_get_html")) {
	require_once("libs/simple_html_dom.php");	
}





?>