<?php
/*
//header('content-type: text/html; charset=iso-8859-2');
header('Content-Type: text/html; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once('function.php');

	$id = addslashes(strip_tags($_GET['id']));
	$limit = addslashes(strip_tags($_GET['limit']));	
	
	
					  
		
		?>
		123
		<?php
		} else {
		?>
		456
        <div class="alert_bg_article">
        <div style="padding:20px 50px 20px 50px;">No more entries</div>
        </div>

		<?	
		}
	}
	*/