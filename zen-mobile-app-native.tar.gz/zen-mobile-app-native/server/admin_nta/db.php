 <?php 
  function lacz_bd()
  {
     $wynik = new mysqli("localhost", "wordpress", "Password1", "wordpress");
     if (!$wynik)
        throw new Exception("Error...Please try again later...");
     else
        return $wynik;
  }
  $base_url = "aqua_wordpress_url";
  $plugin_url = "aqua_wordpress_url/wp-content/plugins/zen-mobile-app-native/";
      $table_prefix = "wp_";
   